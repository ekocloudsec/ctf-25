import boto3
import json
import os

def handler(event, context):
    client = boto3.client('cognito-idp')
    
    # Set default role to 'reader' for new users
    try:
        # El userPoolId viene en el evento mismo
        user_pool_id = event['userPoolId']
        username = event['userName']
        
        client.admin_update_user_attributes(
            UserPoolId=user_pool_id,
            Username=username,
            UserAttributes=[
                {
                    'Name': 'custom:role',
                    'Value': 'reader'
                }
            ]
        )
    except Exception as e:
        print(f"Error updating user attributes: {e}")
        print(f"Event data: {json.dumps(event)}")
    
    return event
